import json
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient

def lambda_handler(event, context):
    print(event)
    print(event["responsePayload"])
    print('Loading function')
    
    response_from_lambda = event["responsePayload"]
    host = "a1kdz3olot79dl-ats.iot.us-east-1.amazonaws.com"
    rootCAPath = "ACNA2-rootca.pem"
    certificatePath = "ACNA2-certificate.pem.crt"
    privateKeyPath = "ACNA2-private.pem.key"
    
    my_rpi = AWSIoTMQTTClient("PubSub-p1726765")
    my_rpi.configureEndpoint(host, 8883)
    my_rpi.configureCredentials(rootCAPath, privateKeyPath, certificatePath)
    
    my_rpi.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
    my_rpi.configureDrainingFrequency(2)  # Draining: 2 Hz
    my_rpi.configureConnectDisconnectTimeout(10)  # 10 sec
    my_rpi.configureMQTTOperationTimeout(5)  # 5 sec
    
    
    my_rpi.connect()

    message_to_send = {}
    message_to_send["source"] = "rekog"
    
    if response_from_lambda == "right_directory_no_match":
        message_to_send["message"] = "right_directory_no_match"
        my_rpi.publish("ACNA2/MQTT_subscription", json.dumps(message_to_send), 1)
        print("It went to the right directory but no faces matched!")
        
    elif response_from_lambda == "tmp_was_not":
        message_to_send["message"] = "tmp_was_not_face"
        my_rpi.publish("ACNA2/MQTT_subscription", json.dumps(message_to_send), 1)
        print("The temporary image was not a face!")
        
    elif response_from_lambda == "wrong_directory_right_face":
        message_to_send["message"] = "user_face_right_face"
        my_rpi.publish("ACNA2/MQTT_subscription", json.dumps(message_to_send), 1)
        print("The face added was a face and saved in the directory!")
        
    elif response_from_lambda == "wrong_directory_not_face":
        message_to_send["message"] = "user_face_not_face"
        my_rpi.publish("ACNA2/MQTT_subscription", json.dumps(message_to_send), 1)
        print("The face was not added as a face and not saved in the directory!")
        
    else:
        message_to_send["message"] ="Match"
        my_rpi.publish("ACNA2/MQTT_subscription", json.dumps(message_to_send), 1)
        print("Temporary match was valid and matched with someone!")
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
